#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execv("/bin/ls",argv);

}
