#include<unistd.h>
#include<stdio.h>

void main(){

int pid1,pid2=0,pid3=0;

pid1=fork();

if(pid1==0){
	printf("\n pid1: %d",getpid());	
	
}

else{ 
	pid2 = fork(); 

	if(pid2==0){
		printf("\n pid2: %d",getpid());	
	}
	else{
		pid3=fork();
		if(pid3==0){
			printf("\n pid3: %d",getpid());
		}
		else{
			waitpid(pid3);
			printf("\nWaiting");
			getchar();
		}

	}

}

}

