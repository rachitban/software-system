#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(){
	mkfifo("myfifo",0666);
}
