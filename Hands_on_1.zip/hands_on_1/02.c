#include<stdio.h>
#include<stdlib.h>

void main(){
	while(1);
}
