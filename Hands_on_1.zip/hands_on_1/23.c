#include<unistd.h>
#include<stdio.h>

void main(){

  
if(fork()!=0){
	
	sleep(50);

}

else{
printf("Child process id: %d",getpid());
}


}
