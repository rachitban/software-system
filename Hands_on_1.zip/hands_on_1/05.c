#include<stdio.h>
#include<fcntl.h>

void main(){
	int fd[5];
	fd[0]=open("test1.txt",O_RDWR|O_CREAT);
	fd[1]=open("test2.txt",O_RDWR|O_CREAT);
	fd[2]=open("test3.txt",O_RDWR|O_CREAT);
	fd[3]=open("test4.txt",O_RDWR|O_CREAT);
	fd[4]=open("test5.txt",O_RDWR|O_CREAT);
	while(1){
		
	}	
}
