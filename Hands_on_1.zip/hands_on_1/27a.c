#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execl("/bin/ls","ls","-Rl",(char *)NULL);


}
