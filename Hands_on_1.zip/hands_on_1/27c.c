#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execle("/bin/ls","ls", "-Rl", (char*)NULL,NULL);

}
