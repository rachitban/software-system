#include<unistd.h>
#include<fcntl.h>
#include<stdio.h>
#include<stdlib.h>

#define RECORD_SIZE 10

void main(){

int fd,i,c;
struct flock lock;
char b[RECORD_SIZE+1];

printf("Enter the record no:\n");
scanf("%d",&i);
printf("Enter 1 for read and 2 for write:\n");
scanf("%d",&c);


	

fd=open("prog18_test.txt",O_RDWR);

if(c==1)
    lock.l_type=F_RDLCK;

else
    lock.l_type=F_WRLCK;

lock.l_start=(i-1)*(RECORD_SIZE+1);
lock.l_whence=SEEK_SET;
lock.l_len=RECORD_SIZE;

if(c==1)
   fcntl(fd,F_SETLK,&lock);
else{
   fcntl(fd,F_SETLKW,&lock);
   printf("Enter %d bytes to write:\n",RECORD_SIZE);
   scanf("%s",b);
}

lseek(fd,(i-1)*(RECORD_SIZE+1),SEEK_SET);

if(c==1){
	read(fd,b,RECORD_SIZE);
	b[RECORD_SIZE]='\0';
	printf("%s",b);
}

else{
	write(fd,b,RECORD_SIZE);
	getchar();
}

getchar();

lock.l_type=F_UNLCK;

if(c==1)
   fcntl(fd,F_SETLK,&lock);
else
   fcntl(fd,F_SETLKW,&lock);


close(fd);




}
