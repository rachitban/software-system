#include<fcntl.h>
#include<unistd.h>
#include<stdio.h>

void main(){

long int fd,n;
fd=open("prog6.c",O_RDWR);
n=fcntl(fd,F_GETFL);
printf("%ld",n & O_ACCMODE);

}
