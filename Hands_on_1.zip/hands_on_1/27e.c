#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execvp("/bin/ls",argv);

}
