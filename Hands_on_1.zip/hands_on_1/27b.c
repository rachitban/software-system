#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execlp("/bin/ls","ls","-Rl",(char *)NULL);;

}
