#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(){
	int i = symlink("Hii.txt","Hi1.txt");
	if(i==0){
		printf("Soft link created");
	}else{
		printf("Soft link not created");
	}
}
