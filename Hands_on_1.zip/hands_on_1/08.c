#include<fcntl.h>
#include<stdio.h>

void main(){

int fd,n,i=0;
char c[1];
char buff[200];

fd=open("6.c",O_RDONLY);

while(1){

n=read(fd,c,1);

if(n==0)
	break;

if(*c=='\n'){
	buff[i]='\0';
	i=0;
	printf("%s\n",buff);
	
}

else{
	buff[i++]=*c;
}

}

buff[i]='\0';
printf("%s",buff);

}
