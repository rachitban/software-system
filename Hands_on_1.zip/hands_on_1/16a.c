#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

void main (){
 
int fd;
static struct flock lock;

fd=open("ticket.txt",O_RDWR|O_CREAT);

lock.l_type=F_WRLCK;
lock.l_len=0;

fcntl(fd,F_SETLKW,&lock);

printf("LOCKED");

getchar();

lock.l_type=F_UNLCK;

fcntl(fd,F_SETLKW,&fd);

close(fd);

}
