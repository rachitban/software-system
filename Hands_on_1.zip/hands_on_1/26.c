#include<unistd.h>
#include<stdio.h>

void main(int argc , char * argv[]){

execl(argv[1],NULL);

}
