#include<fcntl.h>
#include<unistd.h>

void main(){

int fd1,fd2,fd3,n;
char c1[]="hello";
char c2[]="hii";

fd1=open("prog11_test1.txt",O_RDWR | O_CREAT,00700);

fd2=dup(fd1);

n=write(fd1,c1,5);

n=write(fd2,c2,3);

fd3=dup2(fd1,10);

n=write(fd3,c2,3);

fd3=fcntl(fd1,F_DUPFD,11);

n=write(fd3,c2,3);

}


