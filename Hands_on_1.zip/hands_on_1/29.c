#include<stdio.h>
#include<unistd.h>
#include<sched.h>

int main(){
	struct sched_param parameter;
	int pid,policy,answer;
	parameter.sched_priority = 50;
	pid = getpid(); 
	printf("%d ",pid);
	policy = sched_getscheduler(pid);
	printf("%d ",policy);
	getchar();
	answer=sched_setscheduler(pid,SCHED_FIFO,&parameter);
	printf("\n %d",answer);	
	getchar();
}
