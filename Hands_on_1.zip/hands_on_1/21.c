#include<stdio.h>
#include<unistd.h>

void main(){
	
if(fork()==0){
	
	printf("\nChild process id: %d",getpid());	
}

else{

printf("\nPatrent process id: %d",getpid());	

}

}
