#include<unistd.h>
#include<stdio.h>

void main(){

  
if(fork()==0){

printf("Child process id: %d",getpid());
sleep(50);

}


}
