#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(){
	int i = link("Hi.txt","Hihardlink.txt");
	if(i==0){
		printf("Hard link created");
	}else{
		printf("Hard link not created");
	}
}
