#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main(){

int fd;
char buf1[]="Parent says Hola";
char buf2[]="Child says Hello";

fd=open("prog22_test.txt",O_RDWR | O_CREAT,0744);

if(fork()!=0){

write(fd,buf1,sizeof(buf1));

}

else{

write(fd,buf2,sizeof(buf2));

}


}
