#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

void main(){

char c[50];
int n;

n=read(0,c,10);
c[n]='\0';
n=write(1,c,10);

}



