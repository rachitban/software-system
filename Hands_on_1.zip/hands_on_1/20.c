#include<sys/types.h>
#include<unistd.h>
#include<stdio.h>
#include<sys/resource.h>

void main(){


int pid,priority;

pid=getpid();

printf("%d",pid);


priority=getpriority(PRIO_PROCESS,pid);

printf("\n%d",priority);

priority=nice(2);

printf("\n%d",priority);

getchar();

/// top -p pid to get priority


}
