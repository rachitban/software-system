#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>

int main(int argc, char* argv[])
{
    pid_t pid = 0;
    pid_t sid = 0;
    FILE *fp= NULL;
    int i = 0;
    pid = fork();

    if (pid < 0)
    {
        printf("fork failed!\n");
        exit(1);
    }

    if (pid > 0)
    {
       printf("pid of child process %d \n", pid);
        exit(0); 
    }

    umask(0);

    sid = setsid();
    if(sid < 0)
    {
        exit(1);
    }

    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    fp = fopen ("prog30_test.txt", "w+");
    while (i < 10)
    {
        sleep(1);
        fprintf(fp, "%s", "Hola");
        i++;
    }
    fclose(fp);
  
    return (0);
}


