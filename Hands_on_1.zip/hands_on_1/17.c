#include<unistd.h>
#include<fcntl.h>
#include<stdio.h>
#include<stdlib.h>

void main(){

int fd,i=0;
struct flock lock;
char a[1],b[50],d[50];


fd=open("ticket.txt",O_RDWR);

lock.l_type=F_WRLCK;

fcntl(fd,F_SETLKW,&lock);

while(read(fd,a,1)){
	//printf("%c",a[0]);
	b[i++]=a[0];
}

b[i]='\0';

printf("%s",b);

int c=atoi(b);
c++;

snprintf(b,sizeof(b),"%d",c);

lseek(fd,0,SEEK_SET);

write(fd,b,i);

getchar();

lock.l_type=F_UNLCK;

fcntl(fd,F_SETLKW,&lock);

close(fd);

}
