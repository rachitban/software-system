#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>

int main(){

int fd1,fd2,n;
char c[1];

fd1=open("6.c",O_RDONLY | O_EXCL);
fd2=open("prog6_copy.txt",O_RDWR | O_CREAT,00700);

while(read(fd1,c,1)){	
	n=write(fd2,c,1);
}

return 0;
}





