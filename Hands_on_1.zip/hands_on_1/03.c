#include<stdio.h>
#include<fcntl.h>

void main(){
	int fd;
	fd = creat("test.txt",0710);
	printf("%d",fd);
	getchar();
}
