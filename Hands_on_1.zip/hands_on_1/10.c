#include<fcntl.h>
#include<stdio.h>
#include<unistd.h>
#include<sys/types.h>

void main(){

int n;
long int l,fd;
char *c="0123456789";

fd=open("prog10_test.txt",O_RDWR | O_CREAT,00700);

n=write(fd,c,10);

l=lseek(fd,10,SEEK_CUR);

printf("return value of lseek: %ld",l);

c="abcdefghij";

n=write(fd,c,10);



}


