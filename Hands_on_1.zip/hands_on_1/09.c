#include<fcntl.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<time.h>
#include<stdlib.h>
#include<stdio.h>

void main(){

int i;
struct stat s;

i=stat("8.c",&s);

printf("Inode no: %ld\n",(long)s.st_ino);
printf("No of hard links: %ld\n",(long)s.st_nlink);
printf("User Id: %ld\n",(long)s.st_uid);
printf("Group Id: %ld\n",(long)s.st_gid);
printf("Total size no: %ld\n",(long)s.st_size);
printf("Block size: %ld\n",(long)s.st_blksize);
printf("No of 512B blocks: %ld\n",(long)s.st_blocks);
printf("last access time: %s\n",ctime(&s.st_atime));
printf("last modification time: %s\n",ctime(&s.st_mtime));
printf("last status change: %s\n",ctime(&s.st_ctime));


}
