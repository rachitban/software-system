#include<time.h>
#include<unistd.h>
#include<stdio.h>
#include<stdlib.h>

unsigned long long rdtscl(void)
{
    unsigned int lo, hi;
    __asm__ __volatile__ ("rdtsc" : "=a"(lo), "=d"(hi));                        
    return ( (unsigned long long)lo)|( ((unsigned long long)hi)<<32 );  
}

int main() {
  unsigned long long int start,stop;
  start = rdtscl();
  int pid = getpid();
  stop = rdtscl();
  printf("%ld\n",CLOCKS_PER_SEC);
  printf( "%f seconds used by the processor for getpid().\n", ((double)stop-start)/CLOCKS_PER_SEC);
}
