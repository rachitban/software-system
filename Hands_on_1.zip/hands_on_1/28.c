#include<stdio.h>
#include <sched.h>

int main(){
	int maximum,minimum;
	minimum  = sched_get_priority_min(SCHED_FIFO);
	maximum  = sched_get_priority_max(SCHED_FIFO);
	printf("\nMinimum priority FIFO:- %d",minimum);
	printf("\nMaximum priority FIFO:- %d",maximum);

	minimum  = sched_get_priority_min(SCHED_RR);
	maximum  = sched_get_priority_max(SCHED_RR);
	printf("\nMinimum priority RR:- %d",minimum);
	printf("\nMaximum priority RR:- %d",maximum);

}
