#include<sys/select.h>
#include<stdio.h>
#include<fcntl.h>

void main(){

struct timeval t1;
int n,fd;

fd_set rfds,wrfds;

FD_SET(0,&rfds);
FD_SET(1,&wrfds);

t1.tv_sec=10;
t1.tv_usec=0;

n=select(1,&rfds,&wrfds,NULL,&t1);
printf("hii");


}


