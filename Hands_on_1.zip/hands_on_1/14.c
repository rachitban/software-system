#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>

int main( int argc, char *argv[] ){
	struct stat stats;
	char *path=argv[1];
	printf("%s",path);
	if (stat(path, &stats) == 0)
    	{
		struct tm dt;
		
		printf("\nFile access: ");
		if (stats.st_mode & R_OK)
			printf("read ");
                if (stats.st_mode & W_OK)
		        printf("write ");

		if (stats.st_mode & X_OK)
			printf("execute");
	        
		        printf("\nFile size: %ld", stats.st_size);

	        dt = *(gmtime(&stats.st_ctime));
	        printf("\nCreated on: %d-%d-%d %d:%d:%d", dt.tm_mday, dt.tm_mon, dt.tm_year + 1900, 
				                              dt.tm_hour, dt.tm_min, dt.tm_sec);
		    
	        dt = *(gmtime(&stats.st_mtime));
		printf("\nModified on: %d-%d-%d %d:%d:%d", dt.tm_mday, dt.tm_mon, dt.tm_year + 1900, 
                                              		      dt.tm_hour, dt.tm_min, dt.tm_sec);
                                
    	

	 printf("\nFile type: ");

           switch (stats.st_mode & S_IFMT) {
           case S_IFBLK:  printf("block device\n");  break;
           case S_IFCHR:  printf("character device\n"); break;
           case S_IFDIR:  printf("directory\n"); break;
           case S_IFIFO:  printf("FIFO/pipe\n"); break;
           case S_IFLNK:  printf("symlink\n"); break;
           case S_IFREG:  printf("regular file\n");break;
           case S_IFSOCK: printf("socket\n");break;
           default:       printf("unknown?\n");break;
           }



	}
    	
	else
    	{
        	printf("Unable to get file properties.\n");
        	printf("Please check whether '%s' file exists.\n", path);
    	}

    	return 0;
}
