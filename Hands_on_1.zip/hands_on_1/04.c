#include<stdio.h>
#include<fcntl.h>

void main(){
	int fd;
	fd = open("test12.txt",O_RDWR|O_CREAT,0777);
	printf("%d\n",fd);
}
