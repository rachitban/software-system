Run reset.sh to create essential data files:
>sh reset.sh 

sh compile.sh to create object file of server and client:
>sh compile.sh

#Here we are using port 8080
run the server:
>./server

run the client:
>./client [ip_address]

first sign up and create one admin account. 
The secret pin for admin account is "root".

now login into admin account and add trains.

create customers/agents and login to book ticket.

