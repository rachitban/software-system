#include <stdio.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <pthread.h> 
  

void *myThreadFun(void *arg){
 
    printf("Thread  created\n"); 
} 
  
void main(){
    int i; 
    pthread_t tid; 
  
    for (i = 0; i < 3; i++) 
        pthread_create(&tid, NULL, myThreadFun, NULL); 
  
    pthread_exit(NULL); 
} 
