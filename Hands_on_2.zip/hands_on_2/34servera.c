#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

int main(int argc, char const *argv[])
{
	int socket_fd, conn_fd;
	struct sockaddr_in serv_addr;
	
	socket_fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	
	memset(&serv_addr, 0, sizeof(serv_addr));
	
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	serv_addr.sin_port = htons(atoi(argv[1]));

	bind(socket_fd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));
	
	listen(socket_fd, 10);

	while(1)
	{
		conn_fd = accept(socket_fd, (struct sockaddr*)NULL, NULL);
		pid_t pid;
		pid = fork();
		if(pid == 0)
		{ 
			close(socket_fd);
			int size;
			read(conn_fd, &size, sizeof(size));
			size = ntohl(size);
			if(size == -1) break;
			int sum = 0, var;
			for (int i = 0; i < size; ++i)
			{
				read(conn_fd, &var, sizeof(int));
				sum += ntohl(var);
			}
			sum = htonl(sum);
			write(conn_fd, &sum, sizeof(sum));
			close(conn_fd);
		}
		else
		{ 
			close(conn_fd);
		}
	}
	close(socket_fd);
}
