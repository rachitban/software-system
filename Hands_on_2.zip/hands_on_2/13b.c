#include<sys/time.h>
#include<stdio.h>
#include<signal.h>
#include<unistd.h>
#include<sys/types.h>
#include<stdlib.h>

int main(int argc, char* argv[]) {
    int process_id = atoi(argv[1]);
    kill(process_id, SIGSTOP);
    return 0;    
}
