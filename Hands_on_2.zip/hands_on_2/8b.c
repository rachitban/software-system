#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void sig_handler(int signo)
{

if (signo == SIGINT)
    printf(" received SIGINT\n");

exit(0);	

}

void main(){

signal(SIGINT,sig_handler);

while(1);


}
