#include<unistd.h>
#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void HandleSignal(int sig, siginfo_t *si, void *context){

printf("Signal SIGFPEF caught");
exit(0);

}


void main(){


struct sigaction sVal;
sVal.sa_sigaction = HandleSignal;
sigaction(SIGFPE, &sVal, NULL);

int i=1,j=0;
i=i/j;


}
