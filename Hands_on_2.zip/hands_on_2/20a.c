#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){

int fd;
char buff[50];

fd=open("20_fifo",O_WRONLY);  // file has been created using mkfifo on shell

printf("Enter msg to send: ");
scanf("%[^\n]",buff);

write(fd,buff,sizeof(buff));

}
