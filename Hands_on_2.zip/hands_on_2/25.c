// C Program for Message Queue (Reader Process) 
#include <stdio.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 

// structure for message queue 
struct mesg_buffer { 
	long mesg_type; 
	char mesg_text[100]; 
} message; 

int main() 
{ 
	key_t key; 
	int msgid; 
 	struct msqid_ds m;
	key = ftok("5a.c", 65); 
	msgid = msgget(key, 0666 | IPC_CREAT); 
	printf("Message id : %d \n",msgid ); 
	printf("Key : %d \n", key);
	printf("Message Permissions: %u",(m.msg_perm).mode);
	/*b. uid, gid
	c. time of last message sent and received 
	d. time of last change in the message queued. 
	size of thequeue
	f. number of messages in the queue 
	g. maximum number of bytes allowed
	h. pid of the msgsnd and msgrcv*/

	return 0; 
} 

