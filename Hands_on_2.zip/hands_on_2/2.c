#include<stdio.h>
#include<sys/resource.h>
#include<sys/time.h>
#include<unistd.h>

void main(){

struct rlimit rlim;

getrlimit(RLIMIT_CPU,&rlim);

printf("\nCPU Limit : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);

getrlimit(RLIMIT_CORE,&rlim);

printf("\nMax size of core file in bytes : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);

getrlimit(RLIMIT_AS,&rlim);

printf("\nMax size of process virtual memory : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);

getrlimit(RLIMIT_DATA,&rlim);

printf("\nMax size of process data segment : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);

getrlimit(RLIMIT_FSIZE,&rlim);

printf("\nMax size in bytes of files that process may create : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);

getrlimit(RLIMIT_STACK,&rlim);

printf("\nMax size of process's stack in bytes : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);


}
