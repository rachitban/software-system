#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){

int fd,i=0;
char c,buff1[50],buff2[50];

fd=open("22_fifo",O_WRONLY);   // file has been created using mkfifo on shell

printf("Enter msg to send: ");
scanf("%[^\n]",buff1);

write(fd,buff1,sizeof(buff1));

close(fd);

}
