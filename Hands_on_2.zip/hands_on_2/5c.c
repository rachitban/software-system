#include<stdio.h>
#include <unistd.h>

void main(){
	long long int a= sysconf(_SC_CLK_TCK);
	printf("%lld",a);       
}
