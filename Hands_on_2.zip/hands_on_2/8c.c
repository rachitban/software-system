#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void sig_handler(int signo){

printf("received SIGFPE\n");

exit(0);	

}

void main(){

signal(SIGFPE,sig_handler);

int i=1,j=0;

i=i/j;

}
