#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/time.h>
#include<sys/types.h>
#include<signal.h>
#include<stdlib.h>

void sig_handler(int signo)
{

if (signo == SIGSEGV)
    printf("No data received in 10 seconds\n");

exit(0);	

}


void main(){

int fd,i=0,retval;
char c,buff1[50],buff2[50];
struct timeval tv;

fd_set rfds;

tv.tv_sec=10;
tv.tv_usec=0;

fd=open("22_fifo",O_RDONLY);

FD_SET(fd, &rfds);

signal(SIGSEGV,sig_handler);


tv.tv_sec = 10;
tv.tv_usec = 0;

fcntl(fd,F_SETFL,O_NONBLOCK);

/* Wait up to 10 seconds. */

retval = select(1, &rfds, NULL, NULL, &tv);

while(read(fd,&c,1)){ 		
	buff1[i++]=c;
}



buff1[i]='\0';

printf("Msg received: %s",buff1);

close(fd);


}
