#include<stdio.h>
#include <unistd.h>

void main(){
	long long int a= sysconf(_SC_CHILD_MAX);
	printf("%lld",a);       
}
