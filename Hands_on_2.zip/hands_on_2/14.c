#include<unistd.h>
#include<stdio.h>

void main(){


int fd[2];
char buff1[50],buff2[50];

pipe(fd);
printf("Enter data:\n");
scanf("%[^\n]",buff1);

write(fd[1],buff1,sizeof(buff1));
read(fd[0],buff2,sizeof(buff1));

printf("%s",buff2);
}
