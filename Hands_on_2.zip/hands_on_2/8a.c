#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void sig_handler(int signo)
{

if (signo == SIGSEGV)
    printf("received SIGSEGV\n");

exit(0);	

}

void main(){

signal(SIGSEGV,sig_handler);

char *s="hello";

s[1]='i';

}
