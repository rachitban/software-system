#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){

int fd,i=0;
char c,buff[50];

fd=open("20_fifo",O_RDONLY);

while(read(fd,&c,1))
buff[i++]=c;

buff[i]='\0';

printf("Msg received: %s",buff);

}
