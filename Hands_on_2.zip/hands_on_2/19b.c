mkfifo -m 0744 file

