#include<unistd.h>
#include<stdio.h>
#include<sys/wait.h> 

void main(){


int fd1[2],fd2[2];
char buff1[50],buff2[50];

pipe(fd1);
pipe(fd2);

if(fork()){

printf("Enter data to send to child:\n");
scanf("%[^\n]",buff1);

close(fd1[0]);
close(fd2[1]);

write(fd1[1],buff1,sizeof(buff1));

read(fd2[0],buff2,sizeof(buff1));
printf("Message from child: %s\n",buff2);

}

else{

close(fd1[1]);
close(fd2[0]);

read(fd1[0],buff2,sizeof(buff1));
printf("Message from parent: %s\n",buff2);

printf("Enter data to send to parent:\n");
scanf("%[^\n]",buff2);

write(fd2[1],buff2,sizeof(buff2));


}


}
