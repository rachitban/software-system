#include<signal.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>


void main(){

alarm(5);
sleep(10);

}
