// C Program for Message Queue (Writer Process) 
#include <stdio.h> 
#include <sys/ipc.h> 
#include <sys/msg.h> 

// structure for message queue 
struct mesg_buffer { 
	long mesg_type; 
	char mesg_text[100]; 
} message; 

int main() 
{ 
	key_t key; 
	int msgid; 

	key = ftok("2.c", 65); 

	
	msgid = msgget(key, 0666 | IPC_CREAT); 
	

	// display the message 
	printf("Message id : %d \n",msgid ); 
	printf("Key : %d \n", key);

	return 0; 
} 

