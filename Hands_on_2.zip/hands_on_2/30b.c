#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <stdio.h>  

int main() 
{ 
	
	key_t key = ftok("30.c",65); 

	int shmid = shmget(key,1024,0666|IPC_CREAT); 

	char *str = (char*) shmat(shmid,(void*)0,SHM_RDONLY); 
	
	printf("Data read: %s",str);
	
	printf("\nEnter data: "); 
	gets(str);
 
	printf("Data written in memory: %s\n",str); 
	
	shmdt(str); 
	shmctl(shmid,IPC_RMID,NULL);
	
	return 0; 
} 

