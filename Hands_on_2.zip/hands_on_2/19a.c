mknod -m 0744 file2 p

