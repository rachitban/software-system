#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/sem.h>
#include <sys/shm.h>

union semun {              
    int                 val;
    struct semid_ds *   buf;
    unsigned short *    array;
} arg;


int main(){

int semid,shmid;
int key = ftok("32b.c",29); 

if((semid=semget(key,1,IPC_CREAT|0744))==-1)
	exit(0);

arg.val=1;

semctl(semid,0,SETVAL,arg);

struct sembuf buf={0,-1,0};

shmid=shmget(10,100,IPC_CREAT|0744);

int *c = (int *)shmat(shmid,(void*)0,0);
*c=1;

if(fork()){

buf.sem_op=-1;

semop(semid,&buf,1);

(*c)+=2;
printf("%d\n",*c);
buf.sem_op=1;

semop(semid,&buf,1);

}

else{

buf.sem_op=-1;

semop(semid,&buf,1);

(*c)+=5;
printf("%d\n",*c);
buf.sem_op=1;

semop(semid,&buf,1);

}


}
