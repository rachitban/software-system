#include<unistd.h>
#include<signal.h>
#include<stdio.h>
#include<stdlib.h>

void HandleSignal(int sig, siginfo_t *si, void *context){

printf("Signal SIGINT caught");
return;

}


void main(){


struct sigaction sVal;
sVal.sa_sigaction = HandleSignal;
//sVal.sa_handler=SA_SIGINFO;
//sVal.sa_flags=SA_RESETHAND;
sigaction(SIGINT, &sVal, NULL);

while(1);

printf("Hello");

}
