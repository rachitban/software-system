// C code to implement ls | wc command 
#include <stdio.h> 
#include <stdlib.h> 
#include <fcntl.h> 
#include<errno.h> 
#include<sys/wait.h> 
#include <unistd.h> 
int main(){ 

	int a[2]; 

	pipe(a); 

	if(!fork()) 
	{ 
		close(1); 	
		
		fcntl(a[1],F_DUPFD,1);
		
		close(a[0]); 
		
		execlp("ls","ls",NULL); 
	} 
	else
	{ 
		
		close(0); 
		
		fcntl(a[0],F_DUPFD,0); 
		
		
		close(a[1]); 
		
		execlp("wc","wc",NULL); 
	} 
} 

