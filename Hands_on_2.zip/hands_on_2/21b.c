#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main(){

int fd,i=0;
char c,buff1[50],buff2[50];

fd=open("21_fifo",O_RDONLY);

while(read(fd,&c,1)){
buff1[i++]=c;
//printf("i");
}

buff1[i]='\0';

printf("Msg received: %s",buff1);

close(fd);

fd=open("21_fifo",O_WRONLY);

printf("\nEnter msg to send: ");
scanf("%[^\n]",buff2);

write(fd,buff2,sizeof(buff2));

close(fd);

}
