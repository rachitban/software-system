#include<stdio.h>
#include <unistd.h>

void main(){
	long long int a= sysconf(_SC_PHYS_PAGES);
	printf("%lld",a);       
}
