#include<stdio.h>
#include<sys/resource.h>
#include<sys/time.h>
#include<unistd.h>

void main(){

struct rlimit rlim;    // rlim_t rlim_cur -> Soft limit 

rlim.rlim_cur=2;

setrlimit(RLIMIT_CPU,&rlim);

printf("CPU Limit : %lld , %lld",(long long int)rlim.rlim_cur,(long long int)rlim.rlim_max);


}
