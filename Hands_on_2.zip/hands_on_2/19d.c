#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>  
#include <sys/types.h>
#include <sys/stat.h>



int main(){

	  mknod("file4",0777 | S_IFIFO, (dev_t) 0);
}
