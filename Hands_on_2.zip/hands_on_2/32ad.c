#include<stdio.h> 
#include<sys/ipc.h> 
#include<sys/msg.h> 
#include<sys/types.h>
#include<signal.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<ulimit.h>
#include<sys/shm.h>
#include<sys/sem.h>
#include<pthread.h>
#include<semaphore.h>
#include<stdlib.h>

sem_t mutex; 
  
void* thread(void* arg) 
{ 
    //wait 
    sem_wait(&mutex); 
    printf("\nEntered..\n"); 
  
    int fd = open("ticket.txt", O_RDWR);
    char buf[10];
    read(fd, buf, 10);
    int ticket = atoi(buf);
    ticket++;
    lseek(fd, 0, 0);
    sprintf(buf, "%d", ticket);
    write(fd, buf, 10);
    close(fd);
    //signal 
    printf("\nJust Exiting...\n"); 
    sem_post(&mutex); 
} 
  
  
int main() 
{ 
    int fd = open("ticket.txt", O_CREAT|O_RDWR);
    write(fd, "0", 5);
    close(fd);
    sem_init(&mutex, 0, 1); 
    pthread_t t1,t2; 
    pthread_create(&t1,NULL,thread,NULL);     
    pthread_create(&t2,NULL,thread,NULL); 
    pthread_join(t1,NULL); 
    pthread_join(t2,NULL); 
    sem_destroy(&mutex); 
    fd = open("ticket.txt", O_RDONLY);
    char buf[10];
    read(fd, buf, 10);
    write(1, buf, 10);
    return 0; 
} 
