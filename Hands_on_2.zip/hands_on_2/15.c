#include<unistd.h>
#include<stdio.h>

void main(){


int fd[2];
char buff1[50],buff2[50],buff3[50];

pipe(fd);

if(fork()){

printf("Enter data to send to child:\n");
scanf("%[^\n]",buff1);

//close(fd[0]);

write(fd[1],buff1,sizeof(buff1));
//read(fd[0],buff2,sizeof(buff1));
//printf("%s",buff2);

}

else{

close(fd[1]);

read(fd[0],buff3,sizeof(buff1));
printf("\nMessage from parent: %s",buff3);

}


}
