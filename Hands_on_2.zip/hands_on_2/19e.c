#include <unistd.h>
#include <stdio.h>
#include <fcntl.h>   

int main(){

	  mkfifo("file1",0744);
}
