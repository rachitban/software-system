#include<sys/time.h>
#include<stdio.h>
#include<signal.h>
#include<unistd.h>

void sigstop_handler(int sig) {
    printf("Caught SIGSTOP\n");
}

int main() {
    signal(SIGSTOP, sigstop_handler);
    while(1);
    return 0;
}
