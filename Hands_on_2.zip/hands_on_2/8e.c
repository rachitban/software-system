#include<signal.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/time.h>


void main(){

struct itimerval timer;

timer.it_interval.tv_sec=5;
timer.it_interval.tv_usec=0;

timer.it_value.tv_sec=5;
timer.it_value.tv_usec=0;

setitimer(ITIMER_REAL,&timer,NULL);

while(1);

}
