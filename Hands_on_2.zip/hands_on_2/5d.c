#include<stdio.h>
#include <unistd.h>

void main(){
	long long int a= sysconf(_SC_OPEN_MAX);
	printf("%lld",a);       
}
