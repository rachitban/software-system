 #include <stdio.h> 
#include <pthread.h> 
#include <semaphore.h> 
#include <unistd.h>  

int main() 
{ 
	sem_t mutex;
	sem_init(&mutex, 0, 1);    // 1 for binary semaphore 
	return 0; 
} 

