#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void main()
{
	int fd[2];
	pipe(fd);
	if(!fork())//Parent
	{
		dup2(fd[1],1);
		close(fd[0]);
		close(fd[1]);
		execl("/bin/ls","ls","-l",0);
	}
	else//Child
	{
		dup2(fd[0],0);
		close(fd[0]);
		close(fd[1]);
		execl("/usr/bin/wc","wc",0);
	}
	
}
